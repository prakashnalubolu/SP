/*
 * CS 551 Project "Memory manager".
 * This file needs to be turned in.	
 */

#ifndef __INTERPOSITION_H__
#define __INTERPOSITION_H__

#include "memory_manager.h"

#define malloc mem_mngr_alloc
#define free mem_mngr_free

#endif
