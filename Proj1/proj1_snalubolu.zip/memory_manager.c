/*
 * CS 551 Project "Memory manager".
 * This file needs to be turned in.	
 */


#include "memory_manager.h"

static STRU_MEM_LIST * mem_pool = NULL;

/*
 * Print out the current status of the memory manager.
 * Reading this function may help you understand how the memory manager organizes the memory.
 * Do not change the implementation of this function. It will be used to help the grading.
 */
void mem_mngr_print_snapshot(void)
{
    STRU_MEM_LIST * mem_list = NULL;

    printf("============== Memory snapshot ===============\n");

    mem_list = mem_pool; // Get the first memory list
    while(NULL != mem_list)
    {
        STRU_MEM_BATCH * mem_batch = mem_list->first_batch; // Get the first mem batch from the list 

        printf("mem_list %p slot_size %d batch_count %d free_slot_bitmap %p\n", 
                   mem_list, mem_list->slot_size, mem_list->batch_count, mem_list->free_slots_bitmap);
        bitmap_print_bitmap(mem_list->free_slots_bitmap, mem_list->bitmap_size);

        while (NULL != mem_batch)
        {
            printf("\t mem_batch %p batch_mem %p\n", mem_batch, mem_batch->batch_mem);
            mem_batch = mem_batch->next_batch; // get next mem batch
        }

        mem_list = mem_list->next_list;
    }

    printf("==============================================\n");
}

/*
 * Initialize the memory manager with 8 bytes slot size mem_list.
 * Initialize this list with 1 batch of slots.
 */
void mem_mngr_init(void) {
    mem_pool = (STRU_MEM_LIST *)malloc(sizeof(STRU_MEM_LIST));
    if (!mem_pool) {
        perror("Failed to initialize memory manager");
        exit(EXIT_FAILURE);
    }

    mem_pool->slot_size = MEM_ALIGNMENT_BOUNDARY;
    mem_pool->batch_count = 1;
    mem_pool->next_list = NULL;

    mem_pool->bitmap_size = (MEM_BATCH_SLOT_COUNT + 7) / 8;
    mem_pool->free_slots_bitmap = (unsigned char *)malloc(mem_pool->bitmap_size);
    if (!mem_pool->free_slots_bitmap) {
        perror("Failed to initialize bitmap");
        exit(EXIT_FAILURE);
    }
    memset(mem_pool->free_slots_bitmap, 0xFF, mem_pool->bitmap_size); // All slots are free

    STRU_MEM_BATCH *first_batch = (STRU_MEM_BATCH *)malloc(sizeof(STRU_MEM_BATCH));
    if (!first_batch) {
        perror("Failed to initialize memory batch");
        exit(EXIT_FAILURE);
    }

    first_batch->batch_mem = malloc(MEM_BATCH_SLOT_COUNT * MEM_ALIGNMENT_BOUNDARY);
    if (!first_batch->batch_mem) {
        perror("Failed to allocate batch memory");
        exit(EXIT_FAILURE);
    }

    first_batch->next_batch = NULL;

    mem_pool->first_batch = first_batch;
}

/*
 * Clean up the memory manager (e.g., release all the memory allocated)
 */
void mem_mngr_leave(void) {
    STRU_MEM_LIST *current_list = mem_pool;
    while (current_list) {
        STRU_MEM_BATCH *current_batch = current_list->first_batch;
        while (current_batch) {
            STRU_MEM_BATCH *next_batch = current_batch->next_batch;
            free(current_batch->batch_mem);
            free(current_batch);
            current_batch = next_batch;
        }
        free(current_list->free_slots_bitmap);
        STRU_MEM_LIST *next_list = current_list->next_list;
        free(current_list);
        current_list = next_list;
    }
    mem_pool = NULL;
}

/*
 * Allocate a chunk of memory 	
 * @param size: size in bytes to be allocated
 * @return: the pointer to the allocated memory slot
 */
void *mem_mngr_alloc_from_list(STRU_MEM_LIST *list) {
    STRU_MEM_BATCH *current_batch = list->first_batch;

    while (current_batch) {
        for (int i = 0; i < MEM_BATCH_SLOT_COUNT; i++) {
            int byte_index = i / 8;
            int bit_index = i % 8;
            if (list->free_slots_bitmap[byte_index] & (1 << bit_index)) {
                list->free_slots_bitmap[byte_index] &= ~(1 << bit_index);
                return (void *)((char *)current_batch->batch_mem + i * list->slot_size);
            }
        }
        current_batch = current_batch->next_batch;
    }

    // No free slots, need to allocate a new batch
    STRU_MEM_BATCH *new_batch = (STRU_MEM_BATCH *)malloc(sizeof(STRU_MEM_BATCH));
    if (!new_batch) {
        perror("Failed to allocate new memory batch");
        return NULL;
    }

    new_batch->batch_mem = malloc(MEM_BATCH_SLOT_COUNT * list->slot_size);
    if (!new_batch->batch_mem) {
        perror("Failed to allocate new batch memory");
        free(new_batch);
        return NULL;
    }

    new_batch->next_batch = list->first_batch;
    list->first_batch = new_batch;
    list->batch_count++;

    // Allocate from the new batch
    list->free_slots_bitmap[0] &= ~1;
    return new_batch->batch_mem;
}

void *mem_mngr_alloc(size_t size) {
    size = SLOT_ALLINED_SIZE(size);
    if (size > MEM_ALIGNMENT_BOUNDARY) {
        // Handle larger allocations
        STRU_MEM_LIST *current_list = mem_pool;
        STRU_MEM_LIST *prev_list = NULL;

        while (current_list && current_list->slot_size < size) {
            prev_list = current_list;
            current_list = current_list->next_list;
        }

        if (!current_list || current_list->slot_size != size) {
            // Create a new list for this size
            STRU_MEM_LIST *new_list = (STRU_MEM_LIST *)malloc(sizeof(STRU_MEM_LIST));
            if (!new_list) {
                perror("Failed to create new memory list");
                return NULL;
            }

            new_list->slot_size = size;
            new_list->batch_count = 1;
            new_list->next_list = current_list;

            new_list->bitmap_size = (MEM_BATCH_SLOT_COUNT + 7) / 8;
            new_list->free_slots_bitmap = (unsigned char *)malloc(new_list->bitmap_size);
            if (!new_list->free_slots_bitmap) {
                perror("Failed to create new bitmap");
                free(new_list);
                return NULL;
            }
            memset(new_list->free_slots_bitmap, 0xFF, new_list->bitmap_size);

            STRU_MEM_BATCH *new_batch = (STRU_MEM_BATCH *)malloc(sizeof(STRU_MEM_BATCH));
            if (!new_batch) {
                perror("Failed to create new memory batch");
                free(new_list->free_slots_bitmap);
                free(new_list);
                return NULL;
            }

            new_batch->batch_mem = malloc(MEM_BATCH_SLOT_COUNT * size);
            if (!new_batch->batch_mem) {
                perror("Failed to allocate new batch memory");
                free(new_batch);
                free(new_list->free_slots_bitmap);
                free(new_list);
                return NULL;
            }

            new_batch->next_batch = NULL;
            new_list->first_batch = new_batch;

            if (prev_list) {
                prev_list->next_list = new_list;
            } else {
                mem_pool = new_list;
            }

            current_list = new_list;
        }

        // Allocate from the appropriate list
        return mem_mngr_alloc_from_list(current_list);
    } else {
        // Handle 8-byte allocations
        return mem_mngr_alloc_from_list(mem_pool);
    }
}


/*
 * Free a chunk of memory pointed by ptr
 * Print out any error messages
 * @param: the pointer to the allocated memory slot
 */
void mem_mngr_free(void *ptr) {
    if (!ptr) {
        printf("Error: Null pointer\n");
        return;
    }

    STRU_MEM_LIST *current_list = mem_pool;
    while (current_list) {
        STRU_MEM_BATCH *current_batch = current_list->first_batch;
        while (current_batch) {
            if (ptr >= current_batch->batch_mem && ptr < (void *)((char *)current_batch->batch_mem + MEM_BATCH_SLOT_COUNT * current_list->slot_size)) {
                int offset = (char *)ptr - (char *)current_batch->batch_mem;
                if (offset % current_list->slot_size != 0) {
                    printf("Error: Pointer is not aligned\n");
                    return;
                }

                int slot_index = offset / current_list->slot_size;
                int byte_index = slot_index / 8;
                int bit_index = slot_index % 8;

                if (current_list->free_slots_bitmap[byte_index] & (1 << bit_index)) {
                    printf("Error: Double free detected\n");
                    return;
                }

                current_list->free_slots_bitmap[byte_index] |= (1 << bit_index);
                return;
            }
            current_batch = current_batch->next_batch;
        }
        current_list = current_list->next_list;
    }

    printf("Error: Pointer is not managed by memory manager\n");
}

