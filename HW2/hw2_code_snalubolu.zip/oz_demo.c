#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <sys/time.h>

// Function to print events with a timestamp in microseconds
void print_event(const char *event) {
    static struct timeval start;
    static int initialized = 0;
    if (!initialized) {
        gettimeofday(&start, NULL);
        initialized = 1;
    }
    struct timeval now;
    gettimeofday(&now, NULL);
    long long elapsed = (now.tv_sec - start.tv_sec) * 1000000LL + (now.tv_usec - start.tv_usec);
    printf("%lld us: %s\n", elapsed, event);
}

int main() {
    pid_t parent_pid, child_pid = -1;
    int status;

    print_event("Grandparent process created");
    
    parent_pid = fork();
    if (parent_pid == 0) {
        // Parent process
        print_event("Parent process created");
        
        child_pid = fork();
        if (child_pid == 0) {
            // Child process
            print_event("Child process created");
            
            // Busy polling to detect adoption by init
            while (getppid() != 1) {
                usleep(100000); // Check every 100 ms
            }
            print_event("Child process adopted by init");
            exit(0);
        }
        
        // Parent sleeps for 3 seconds before terminating
        usleep(3000000);
        print_event("Parent process terminating");
        exit(0);
    }
    
    // Grandparent sleeps for 6 seconds before performing wait()
    usleep(6000000);
    print_event("Grandparent process wakes up");
    waitpid(parent_pid, &status, 0); // Waits for parent to terminate
    print_event("wait() on parent returns");

    // Ensure the child process also terminates cleanly
    waitpid(child_pid, &status, 0);
    print_event("Child process has terminated");
    
    print_event("Grandparent process terminated");
    return 0;
}

/* Observations:
1. The parent process terminates after 3 seconds, becoming a zombie until the grandparent invokes wait().
2. The child process is quickly adopted by init after the parent terminates, confirming that the init adoption happens immediately when the parent process exits.
3. The grandparent wakes up after 6 seconds and then performs a wait() on the parent process, reaping the zombie process immediately.
4. The grandparent also ensures the child process terminates cleanly, thus ensuring all processes are properly managed and no orphan processes are left.
*/
