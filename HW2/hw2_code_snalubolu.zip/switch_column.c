#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LINE_LENGTH 64

// Function to switch columns and prepare the output line
void switch_column(char *output, char *line, int col1, int col2) {
    char *tokens[MAX_LINE_LENGTH / 2 + 1]; // Maximum possible tokens
    int numTokens = 0;
    char *token;

    // Tokenize the line
    token = strtok(line, " \t");
    while (token != NULL) {
        tokens[numTokens++] = token;
        token = strtok(NULL, " \t");
    }

    // Adjust indices to be zero-based
    col1--; col2--;

    // Switch if indices are valid
    if (col1 < numTokens && col2 < numTokens && col1 != col2) {
        char *temp = tokens[col1];
        tokens[col1] = tokens[col2];
        tokens[col2] = temp;
    }

    // Build the switched line
    output[0] = '\0'; // Start with an empty string
    for (int i = 0; i < numTokens; i++) {
        strcat(output, tokens[i]);
        if (i < numTokens - 1) strcat(output, " "); // Add space between tokens, not at the end
    }
}

int main(int argc, char *argv[]) {
    if (argc != 4) {
        fprintf(stderr, "Usage: %s path_to_file col_1_idx col_2_idx\n", argv[0]);
        return 1;
    }

    const char *filePath = argv[1];
    int col1_idx = atoi(argv[2]);
    int col2_idx = atoi(argv[3]);

    FILE *file = fopen(filePath, "r+");
    if (!file) {
        perror("File opening failed");
        return EXIT_FAILURE;
    }

    char line[MAX_LINE_LENGTH + 1];
    char outputBuffer[8192] = ""; // Larger buffer to store all output lines
    char modifiedLine[MAX_LINE_LENGTH + 1];

    // Read all lines, process them and store in the buffer
    while (fgets(line, sizeof(line), file)) {
        line[strcspn(line, "\n")] = '\0'; // Remove newline character
        switch_column(modifiedLine, line, col1_idx, col2_idx);
        strcat(outputBuffer, modifiedLine);
        strcat(outputBuffer, "\n"); // Add newline back for each line
    }

    // Move to the end of the file and write all at once
    fseek(file, 0, SEEK_END);
    fputs("\n=========\n", file); // Divider to show the difference between previous file and modified file
    fputs(outputBuffer, file);

    fclose(file);
    return 0;
}
