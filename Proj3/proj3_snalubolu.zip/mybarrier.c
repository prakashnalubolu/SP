#include <stdlib.h>
#include "mybarrier.h"

//Implementation of mybarrier_init()
mybarrier_t *mybarrier_init(unsigned int count) {
    mybarrier_t *barrier = malloc(sizeof(*barrier));
    if (barrier == NULL) {
        return NULL;
    }
    
    barrier->count = count;
    barrier->waiting = 0;
    barrier->broken = 0;
    barrier->destroyed = 0;
    pthread_mutex_init(&barrier->mutex, NULL);
    pthread_cond_init(&barrier->cond, NULL);
    
    return barrier;
}
//Implementation of mybarrier_destroy()
int mybarrier_destroy(mybarrier_t *barrier) {
    if (barrier == NULL) {
        return -1;
    }

    pthread_mutex_lock(&barrier->mutex);

    if (barrier->destroyed) {
        pthread_mutex_unlock(&barrier->mutex);
        return -1;
    }

    barrier->destroyed = 1;

    // Unblock all waiting threads
    if (!barrier->broken) {
        barrier->broken = 1;
        pthread_cond_broadcast(&barrier->cond);
    }

    // Wait until all threads have finished waiting
    while (barrier->waiting > 0) {
        pthread_cond_broadcast(&barrier->cond);
        pthread_mutex_unlock(&barrier->mutex);
        pthread_mutex_lock(&barrier->mutex);
    }

    pthread_mutex_unlock(&barrier->mutex);
    pthread_mutex_destroy(&barrier->mutex);
    pthread_cond_destroy(&barrier->cond);
    free(barrier);

    return 0;
}
//Implementation of mybarrier_wait()
int mybarrier_wait(mybarrier_t *barrier) {
    if (barrier == NULL) {
        return -1;
    }

    pthread_mutex_lock(&barrier->mutex);

    if (barrier->broken || barrier->destroyed) {
        pthread_mutex_unlock(&barrier->mutex);
        return -1;
    }

    barrier->waiting++;

    if (barrier->waiting >= barrier->count) {
        barrier->broken = 1;
        pthread_cond_broadcast(&barrier->cond);
    } else {
        while (!barrier->broken && !barrier->destroyed) {
            pthread_cond_wait(&barrier->cond, &barrier->mutex);
        }
    }

    barrier->waiting--;
    int destroyed = barrier->destroyed;
    pthread_mutex_unlock(&barrier->mutex);
    
    return (destroyed) ? -1 : 0;
}
