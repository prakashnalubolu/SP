#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <string.h>
#include "mapreduce.h"
#include "common.h"
#include "usr_functions.h"

void mapreduce(MAPREDUCE_SPEC * spec, MAPREDUCE_RESULT * result)
{
    struct timeval start, end;

    if (NULL == spec || NULL == result)
    {
        EXIT_ERROR(ERROR, "NULL pointer!\n");
    }
    
    gettimeofday(&start, NULL);

    // Step 1: Partition the input file
    int fd = open(spec->input_data_filepath, O_RDONLY);
    if (fd == -1) {
        EXIT_ERROR(ERROR, "Error opening file!\n");
    }

    // Get the size of the file
    off_t file_size = lseek(fd, 0, SEEK_END);
    lseek(fd, 0, SEEK_SET);

    // Calculate the size of each split
    off_t split_size = file_size / spec->split_num;
    
    // Create data splits
    DATA_SPLIT splits[spec->split_num];
    for (int i = 0; i < spec->split_num; i++) {
        splits[i].fd = fd;
        splits[i].size = (i == spec->split_num - 1) ? (file_size - i * split_size) : split_size;
        splits[i].usr_data = spec->usr_data;
        splits[i].offset = i * split_size;  // Set the offset for each split
    }

    // Step 2: Fork worker processes for the map phase
    int intermediate_fds[spec->split_num];
    for (int i = 0; i < spec->split_num; i++) {
        char filename[20];
        sprintf(filename, "mr-%d.itm", i);
        if ((intermediate_fds[i] = open(filename, O_WRONLY | O_CREAT | O_TRUNC, 0666)) == -1) {
            EXIT_ERROR(ERROR, "Error opening intermediate file!\n");
        }

        pid_t pid = fork();
        if (pid == 0) { // Child process
            if (spec->map_func(&splits[i], intermediate_fds[i]) == -1) {
                exit(EXIT_FAILURE);
            }
            close(intermediate_fds[i]);
            exit(EXIT_SUCCESS);
        } else if (pid > 0) {
            result->map_worker_pid[i] = pid;
        } else {
            perror("Fork failed");
            exit(EXIT_FAILURE);
        }
    }

    // Wait for all map workers to finish
    for (int i = 0; i < spec->split_num; i++) {
        int status;
        waitpid(result->map_worker_pid[i], &status, 0);
    }

    // Close the file descriptor for the original file
    close(fd);

    // Reopen intermediate files for reading
    for (int i = 0; i < spec->split_num; i++) {
        char filename[20];
        sprintf(filename, "mr-%d.itm", i);
        intermediate_fds[i] = open(filename, O_RDONLY);
        if (intermediate_fds[i] == -1) {
            EXIT_ERROR(ERROR, "Error reopening intermediate file!\n");
        }
    }

    // Step 3: Run reduce function
    int final_result_fd = open(result->filepath, O_WRONLY | O_CREAT | O_TRUNC, 0666);
    if (final_result_fd == -1) {
        EXIT_ERROR(ERROR, "Error opening result file!\n");
    }

    pid_t reduce_pid = fork();
    if (reduce_pid == 0) { // Reduce worker process
        if (spec->reduce_func(intermediate_fds, spec->split_num, final_result_fd) == -1) {
            exit(EXIT_FAILURE);
        }
        close(final_result_fd);
        exit(EXIT_SUCCESS);
    } else if (reduce_pid > 0) {
        result->reduce_worker_pid = reduce_pid;
    } else {
        perror("Fork failed");
        exit(EXIT_FAILURE);
    }

    // Wait for reduce worker to finish
    int status;
    waitpid(result->reduce_worker_pid, &status, 0);

    // Close all intermediate file descriptors
    for (int i = 0; i < spec->split_num; i++) {
        close(intermediate_fds[i]);
    }

    close(final_result_fd);

    gettimeofday(&end, NULL);

    result->processing_time = (end.tv_sec - start.tv_sec) * US_PER_SEC + (end.tv_usec - start.tv_usec);
}
