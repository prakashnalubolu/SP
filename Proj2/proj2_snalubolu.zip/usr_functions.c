#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <ctype.h>
#include "common.h"
#include "usr_functions.h"

/* User-defined map function for the "Letter counter" task.  
   This map function is called in a map worker process.
   @param split: The data split that the map function is going to work on.
                 Note that the file offset of the file descripter split->fd should be set to the properly
                 position when this map function is called.
   @param fd_out: The file descriptor of the itermediate data file output by the map function.
   @ret: 0 on success, -1 on error.
 */
int letter_counter_map(DATA_SPLIT * split, int fd_out)
{
    char *buffer = malloc(split->size + 1);
    if (buffer == NULL) {
        perror("Failed to allocate buffer");
        return -1;
    }
    
    if (lseek(split->fd, split->offset, SEEK_SET) == -1) {
        perror("Failed to seek to offset");
        free(buffer);
        return -1;
    }

    ssize_t bytes_read = read(split->fd, buffer, split->size);
    if (bytes_read == -1) {
        perror("Failed to read split");
        free(buffer);
        return -1;
    }
    buffer[bytes_read] = '\0';

    int counts[26] = {0};
    for (ssize_t i = 0; i < bytes_read; i++) {
        if (buffer[i] >= 'A' && buffer[i] <= 'Z') {
            counts[buffer[i] - 'A']++;
        } else if (buffer[i] >= 'a' && buffer[i] <= 'z') {
            counts[buffer[i] - 'a']++;
        }
    }

    for (int i = 0; i < 26; i++) {
        char output[10];
        sprintf(output, "%c %d\n", 'A' + i, counts[i]);
        ssize_t bytes_written = write(fd_out, output, strlen(output));
        if (bytes_written == -1) {
            perror("Failed to write to intermediate file");
            free(buffer);
            return -1;
        }
    }

    free(buffer);
    return 0;
}

/* User-defined reduce function for the "Letter counter" task.  
   This reduce function is called in a reduce worker process.
   @param p_fd_in: The address of the buffer holding the intermediate data files' file descriptors.
                   The imtermeidate data files are output by the map worker processes, and they
                   are the input for the reduce worker process.
   @param fd_in_num: The number of the intermediate files.
   @param fd_out: The file descriptor of the final result file.
   @ret: 0 on success, -1 on error.
   @example: if fd_in_num == 3, then there are 3 intermediate files, whose file descriptor is 
             identified by p_fd_in[0], p_fd_in[1], and p_fd_in[2] respectively.
*/
int letter_counter_reduce(int * p_fd_in, int fd_in_num, int fd_out)
{
    int total_counts[26] = {0};
    char buffer[256];

    for (int i = 0; i < fd_in_num; i++) {
        if (lseek(p_fd_in[i], 0, SEEK_SET) == -1) {
            perror("Failed to seek to offset in intermediate file");
            return -1;
        }

        while (1) {
            ssize_t bytes_read = read(p_fd_in[i], buffer, sizeof(buffer) - 1);
            if (bytes_read == 0) break;
            if (bytes_read < 0) {
                perror("Failed to read intermediate file");
                return -1;
            }
            buffer[bytes_read] = '\0';

            char *line = strtok(buffer, "\n");
            while (line != NULL) {
                char letter;
                int count;
                if (sscanf(line, "%c %d", &letter, &count) == 2) {
                    total_counts[letter - 'A'] += count;
                }
                line = strtok(NULL, "\n");
            }
        }
        close(p_fd_in[i]);
    }

    for (int i = 0; i < 26; i++) {
        char output[10];
        sprintf(output, "%c %d\n", 'A' + i, total_counts[i]);
        ssize_t bytes_written = write(fd_out, output, strlen(output));
        if (bytes_written == -1) {
            perror("Failed to write to result file");
            return -1;
        }
    }

    return 0;
}

// Bonus
/* User-defined map function for the "Word finder" task.  
   This map function is called in a map worker process.
   @param split: The data split that the map function is going to work on.
                 Note that the file offset of the file descripter split->fd should be set to the properly
                 position when this map function is called.
   @param fd_out: The file descriptor of the itermediate data file output by the map function.
   @ret: 0 on success, -1 on error.
 */
int is_whole_word_match(const char *str, const char *word, int word_len) {
    if ((str == word || !isalnum((unsigned char)*(str - 1))) && !isalnum((unsigned char)*(str + word_len))) {
        return 1;
    }
    return 0;
}

int word_finder_map(DATA_SPLIT * split, int fd_out)
{
    char *buffer = malloc(split->size + 1);
    if (buffer == NULL) {
        perror("Failed to allocate buffer");
        return -1;
    }

    if (lseek(split->fd, split->offset, SEEK_SET) == -1) {
        perror("Failed to seek to offset");
        free(buffer);
        return -1;
    }

    ssize_t bytes_read = read(split->fd, buffer, split->size);
    if (bytes_read == -1) {
        perror("Failed to read split");
        free(buffer);
        return -1;
    }
    buffer[bytes_read] = '\0';

    char *word_to_find = (char *)split->usr_data;
    int word_len = strlen(word_to_find);

    char *line = strtok(buffer, "\n");
    while (line != NULL) {
        char *ptr = line;
        int found = 0;
        while ((ptr = strstr(ptr, word_to_find)) != NULL) {
            if (is_whole_word_match(ptr, word_to_find, word_len)) {
                found = 1;
                break;
            }
            ptr++;
        }

        if (found) {
            ssize_t bytes_written = write(fd_out, line, strlen(line));
            if (bytes_written == -1) {
                perror("Failed to write to intermediate file");
                free(buffer);
                return -1;
            }
            if (write(fd_out, "\n", 1) == -1) {
                perror("Failed to write newline to intermediate file");
                free(buffer);
                return -1;
            }
        }
        line = strtok(NULL, "\n");
    }

    free(buffer);
    return 0;
}

// Bonus
/* User-defined reduce function for the "Word finder" task.  
   This reduce function is called in a reduce worker process.
   @param p_fd_in: The address of the buffer holding the intermediate data files' file descriptors.
                   The imtermeidate data files are output by the map worker processes, and they
                   are the input for the reduce worker process.
   @param fd_in_num: The number of the intermediate files.
   @param fd_out: The file descriptor of the final result file.
   @ret: 0 on success, -1 on error.
   @example: if fd_in_num == 3, then there are 3 intermediate files, whose file descriptor is 
             identified by p_fd_in[0], p_fd_in[1], and p_fd_in[2] respectively.
*/
int word_finder_reduce(int * p_fd_in, int fd_in_num, int fd_out)
{
    char buffer[256];
    for (int i = 0; i < fd_in_num; i++) {
        if (lseek(p_fd_in[i], 0, SEEK_SET) == -1) {
            perror("Failed to seek to offset in intermediate file");
            return -1;
        }

        while (1) {
            ssize_t bytes_read = read(p_fd_in[i], buffer, sizeof(buffer) - 1);
            if (bytes_read == 0) break;  // End of file
            if (bytes_read < 0) {
                perror("Failed to read intermediate file");
                return -1;
            }
            buffer[bytes_read] = '\0';

            ssize_t bytes_written = write(fd_out, buffer, bytes_read);
            if (bytes_written == -1) {
                perror("Failed to write to result file");
                return -1;
            }
        }
        close(p_fd_in[i]);
    }
    return 0;
}
