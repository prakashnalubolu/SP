#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int count_occurrences(const char *str, const char *substr) {
    int count = 0;
    size_t len_substr = strlen(substr);
    if (len_substr == 0) {
        return 0; // Substring with length 0 should not match anything.
    }
    for (const char *p = str; *p != '\0'; p++) {
        if (strncasecmp(p, substr, len_substr) == 0) {
            count++;
        }
    }
    return count;
}

int str_manip(char *str, char *substr) {
    if (str == NULL || substr == NULL) {
        fprintf(stderr, "Error: NULL input argument\n");
        return -1;
    }

    // Print the original string
    printf("str %s\n", str);

    // Handle empty input string
    if (strlen(str) == 0) {
        printf("The string is empty please enter a string which has atleast one character.\n");
        printf("newstr \n");
        printf("substr %s\n", substr);
        printf("occurences 0\n");
        return 0;
    }

    // Create the new string (str + reversed str, all in lowercase)
    size_t len = strlen(str);
    char *newstr = (char *)malloc(2 * len + 1);
    if (newstr == NULL) {
        fprintf(stderr, "Error: Memory allocation failed\n");
        return -1;
    }

    for (size_t i = 0; i < len; i++) {
        newstr[i] = tolower(str[i]);
    }
    for (size_t i = 0; i < len; i++) {
        newstr[len + i] = tolower(str[len - i - 1]);
    }
    newstr[2 * len] = '\0';

    // Print the new string
    printf("newstr %s\n", newstr);

    // Print the substring
    printf("substr %s\n", substr);

    // Count occurrences of substr in newstr (case-insensitive, overlapping)
    int occurrences = count_occurrences(newstr, substr);

    // Print the number of occurrences
    printf("occurences %d\n", occurrences);

    // Free allocated memory
    free(newstr);

    return 0;
}


