#ifndef HW1_H
#define HW1_H

#include <stdio.h>
#include <stdarg.h>

// Redefine printf to myprintf
#define printf(format, ...) myprintf(format, ##__VA_ARGS__)

// Declaration of myprintf
void myprintf(const char *format, ...);

// Declaration of str
int str_manip(char *str, char *substr);

// Variadic macro to print message along with filename and line number
#define MYMSG(format, ...) \
    myprintf("Original message --> %s:%d: " format, __FILE__, __LINE__, ##__VA_ARGS__)

#endif // HW1_H
