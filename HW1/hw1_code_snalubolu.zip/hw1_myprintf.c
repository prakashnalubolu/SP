#include <stdio.h>
#include <stdarg.h>
#include <string.h>

//myprintf is a variadic function that can take any number of arguments

void myprintf(const char *format, ...) {
    va_list args;
    const char *p;
    int int_val;
    char char_val;
    char *str_val;

    // Start the variable argument list
    va_start(args, format);

    // First, print the formatted string as a normal printf would do
    vprintf(format, args);

    // Restart the argument list for parsing
    va_start(args, format);

    printf("Argument list:\n");

    for (p = format; *p != '\0'; p++) {
        if (*p == '%') {
            p++;
            switch (*p) {
                case 'c':
                    char_val = (char) va_arg(args, int);
                    printf("Char --> %c\n", char_val);
                    break;
                case 'd':
                    int_val = va_arg(args, int);
                    printf("Integer --> %d\n", int_val);
                    break;
                case 's':
                    str_val = va_arg(args, char *);
                    printf("String --> %s\n", str_val);
                    break;
                default:
                    break;
            }
        }
    }

    // Clean up the argument list
    va_end(args);
}



